"""Create demo videos/audio with KNOWN physics, so you can check the analyser is right.

    python examples/make_demo_videos.py

Creates (in the examples/ folder):
    pendulum.mp4    L = 0.60 m, damping gamma = 0.15 /s       scale 0.002 m/px
    projectile.mp4  g = 9.81, speed 6 m/s at 55 degrees        scale 0.00667 m/px
    spring.mp4      k = 20 N/m, m = 0.5 kg, gamma = 0.20 /s    scale 0.002 m/px
    string.wav      G3 string (196 Hz), length 0.65 m
"""
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.io import wavfile

ORANGE_BGR = (0, 128, 255)
W, H = 640, 480


def _writer(path, fps):
    return cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (W, H))


def _ball(frame, x, y, radius):
    """Draw a sub-pixel-accurate orange ball."""
    s = 4  # 4 bits of sub-pixel precision
    cv2.circle(frame, (int(round(x * 2 ** s)), int(round(y * 2 ** s))),
               int(radius * 2 ** s), ORANGE_BGR, -1, cv2.LINE_AA, shift=s)


def make_pendulum(out_dir, L=0.60, gamma=0.15, g=9.81, theta0=0.25, fps=30, seconds=10,
                  px_per_m=500):
    path = Path(out_dir) / "pendulum.mp4"
    w = np.sqrt(g / L - gamma ** 2)
    pivot = (W / 2, 60)
    vw = _writer(path, fps)
    for i in range(int(fps * seconds)):
        t = i / fps
        theta = theta0 * np.exp(-gamma * t) * np.cos(w * t)
        frame = np.full((H, W, 3), 255, np.uint8)
        bx = pivot[0] + L * px_per_m * np.sin(theta)
        by = pivot[1] + L * px_per_m * np.cos(theta)
        cv2.line(frame, (int(pivot[0]), int(pivot[1])), (int(bx), int(by)), (60, 60, 60), 2)
        _ball(frame, bx, by, 18)
        vw.write(frame)
    vw.release()
    return path


def make_projectile(out_dir, v0=6.0, angle_deg=55, g=9.81, fps=60, px_per_m=150):
    path = Path(out_dir) / "projectile.mp4"
    a = np.radians(angle_deg)
    flight = 2 * v0 * np.sin(a) / g
    vw = _writer(path, fps)
    for i in range(int(fps * flight)):
        t = i / fps
        x = 40 + v0 * np.cos(a) * t * px_per_m
        y = 440 - (v0 * np.sin(a) * t - 0.5 * g * t * t) * px_per_m
        frame = np.full((H, W, 3), 255, np.uint8)
        _ball(frame, x, y, 12)
        vw.write(frame)
    vw.release()
    return path


def make_spring(out_dir, k=20.0, m=0.5, gamma=0.2, amp=0.08, fps=30, seconds=10, px_per_m=500):
    path = Path(out_dir) / "spring.mp4"
    w = np.sqrt(k / m - gamma ** 2)
    vw = _writer(path, fps)
    for i in range(int(fps * seconds)):
        t = i / fps
        y = 240 + amp * np.exp(-gamma * t) * np.cos(w * t) * px_per_m
        frame = np.full((H, W, 3), 255, np.uint8)
        cv2.line(frame, (W // 2, 0), (W // 2, int(y)), (120, 120, 120), 3)
        _ball(frame, W / 2, y, 16)
        vw.write(frame)
    vw.release()
    return path


def make_string_audio(out_dir, f1=196.0, rate=44100, seconds=2.0):
    path = Path(out_dir) / "string.wav"
    t = np.arange(int(rate * seconds)) / rate
    sig = sum(a * np.sin(2 * np.pi * f1 * n * t) for n, a in enumerate((1, .5, .33, .25), 1))
    sig *= np.exp(-3 * t)
    wavfile.write(path, rate, (sig / np.max(np.abs(sig)) * 32000).astype(np.int16))
    return path


def main(out_dir=None):
    out_dir = Path(out_dir or Path(__file__).parent)
    out_dir.mkdir(parents=True, exist_ok=True)
    for fn in (make_pendulum, make_projectile, make_spring, make_string_audio):
        print("created", fn(out_dir))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
