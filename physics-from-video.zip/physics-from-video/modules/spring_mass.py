"""Mass bouncing on a spring: frequency, spring constant, damping."""
import numpy as np

from core.filtering import dominant_axis
from core.fitting import fit_damped_oscillation
from modules.base import PhysicsModule, Result


class SpringMass(PhysicsModule):
    name = "spring"
    description = "Mass on a spring -> frequency, spring constant k, damping"
    input_kind = "video"
    options = {"mass_kg": "Hanging mass in kilograms (needed to get k)"}

    def analyze(self, t, x, y, mass_kg=None, **_):
        signal, axis = dominant_axis(x, y)
        fit = fit_damped_oscillation(t, signal)

        w_d, gamma = fit["omega"], fit["gamma"]
        w0 = float(np.hypot(w_d, gamma))
        params = {
            "Oscillation frequency": (w_d / (2 * np.pi), "Hz"),
            "Period": (2 * np.pi / w_d, "s"),
            "Natural frequency (w0)": (w0, "rad/s"),
            "Damping rate (gamma)": (gamma, "1/s"),
            "Amplitude": (abs(fit["A"]), "m"),
        }
        notes = ["Model: m x'' + b x' + k x = 0  ->  w0^2 = k/m, gamma = b/(2m)."]
        if mass_kg:
            params["Spring constant k"] = (mass_kg * w0 ** 2, "N/m")
            params["Damping coefficient b"] = (2 * mass_kg * gamma, "kg/s")
        else:
            notes.append("Give the mass (--mass) to also get k and b.")

        return Result(module=self.name, title="Spring-mass analysis", params=params,
                      t=t, observed=signal, fitted=fit["fitted"], r2=fit["r2"],
                      ylabel=f"{axis} position (m)", notes=notes)
