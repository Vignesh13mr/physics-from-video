"""Registry of physics modules. To add a new one, import it and add it to MODULES."""
from modules.pendulum import Pendulum
from modules.projectile import Projectile
from modules.sound import Sound
from modules.spring_mass import SpringMass

MODULES = {m.name: m for m in (Pendulum(), Projectile(), SpringMass(), Sound())}


def get_module(name):
    if name not in MODULES:
        raise KeyError(f"Unknown module '{name}'. Available: {', '.join(MODULES)}")
    return MODULES[name]
