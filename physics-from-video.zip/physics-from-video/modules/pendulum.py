"""Swinging pendulum: period, damping and length (or g)."""
import numpy as np

from core.filtering import dominant_axis
from core.fitting import fit_damped_oscillation
from modules.base import PhysicsModule, Result


class Pendulum(PhysicsModule):
    name = "pendulum"
    description = "Swinging pendulum -> period, damping, length or g"
    input_kind = "video"
    options = {"length_m": "Length of the string in metres (optional, lets us estimate g)"}

    def analyze(self, t, x, y, length_m=None, g=9.81, **_):
        signal, axis = dominant_axis(x, y)
        fit = fit_damped_oscillation(t, signal)

        w_d, gamma = fit["omega"], fit["gamma"]
        w0 = float(np.hypot(w_d, gamma))          # natural angular frequency
        params = {
            "Period": (2 * np.pi / w_d, "s"),
            "Natural frequency (w0)": (w0, "rad/s"),
            "Damping rate (gamma)": (gamma, "1/s"),
            "Swing amplitude": (abs(fit["A"]), "m"),
        }
        notes = ["Small-angle model: w0^2 = g / L. Length means pivot to centre of the bob."]
        if length_m:
            params["g (from your length)"] = (w0 ** 2 * length_m, "m/s^2")
            if abs(fit["A"]) / length_m > 0.3:
                notes.append("Swings are large (> ~17 deg); the small-angle model is less accurate.")
        else:
            params["Effective length (if g = 9.81)"] = (g / w0 ** 2, "m")

        return Result(module=self.name, title="Pendulum analysis", params=params,
                      t=t, observed=signal, fitted=fit["fitted"] + 0 * t, r2=fit["r2"],
                      ylabel=f"{axis} position (m)", notes=notes)
