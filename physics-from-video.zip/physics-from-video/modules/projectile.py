"""Thrown ball: gravity, launch speed and angle."""
import numpy as np

from core.fitting import r_squared
from modules.base import PhysicsModule, Result


class Projectile(PhysicsModule):
    name = "projectile"
    description = "Thrown or bouncing-free ball flight -> g, launch speed, angle"
    input_kind = "video"

    def analyze(self, t, x, y, **_):
        t0 = t - t[0]
        ax, bx = np.polyfit(t0, x, 1)            # x = bx + ax*t  (constant horizontal speed)
        c2, c1, c0 = np.polyfit(t0, y, 2)        # y = c0 + c1*t + c2*t^2
        y_fit = np.polyval([c2, c1, c0], t0)

        g = -2 * c2
        vx, vy = ax, c1
        params = {
            "Gravity (g)": (g, "m/s^2"),
            "Launch speed": (float(np.hypot(vx, vy)), "m/s"),
            "Launch angle": (float(np.degrees(np.arctan2(vy, abs(vx)))), "deg"),
            "Horizontal speed": (abs(vx), "m/s"),
            "Max height above start": (float(c1 ** 2 / (2 * g)) if g > 0 else float("nan"), "m"),
            "Flight time analysed": (float(t0[-1]), "s"),
        }
        notes = ["Model ignores air drag. Use --start/--end to keep only the flight "
                 "(after release, before landing)."]
        return Result(module=self.name, title="Projectile analysis", params=params,
                      t=t, observed=y, fitted=y_fit, r2=r_squared(y, y_fit),
                      ylabel="height (m)", notes=notes)
