"""Common building blocks for every physics module."""
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from matplotlib.figure import Figure


@dataclass
class Result:
    """What every module returns: numbers, a fit, and a plot."""
    module: str
    title: str
    params: dict                      # name -> (value, unit)
    t: np.ndarray                     # x-axis data (time, or frequency for sound)
    observed: np.ndarray              # measured values
    fitted: Optional[np.ndarray] = None
    r2: Optional[float] = None
    xlabel: str = "time (s)"
    ylabel: str = ""
    notes: list = field(default_factory=list)
    markers: list = field(default_factory=list)   # vertical guide lines
    xlim: Optional[tuple] = None
    line_observed: bool = False       # draw measured data as a line instead of dots

    def summary(self):
        lines = [self.title, "-" * len(self.title)]
        for name, (value, unit) in self.params.items():
            lines.append(f"{name}: {value:.4g} {unit}".rstrip())
        if self.r2 is not None:
            lines.append(f"Fit quality (R²): {self.r2:.4f}")
        lines += [f"Note: {n}" for n in self.notes]
        return "\n".join(lines)

    def plot(self):
        fig = Figure(figsize=(8, 4.2))
        ax = fig.subplots()
        if self.line_observed:
            ax.plot(self.t, self.observed, "-", lw=1.2, label="measured")
        else:
            ax.plot(self.t, self.observed, ".", ms=4, alpha=0.6, label="measured")
        if self.fitted is not None:
            label = "fit" if self.r2 is None else f"fit (R²={self.r2:.3f})"
            ax.plot(self.t, self.fitted, "-", lw=2, label=label)
        for m in self.markers:
            ax.axvline(m, ls="--", alpha=0.4, color="gray")
        if self.xlim:
            ax.set_xlim(*self.xlim)
        ax.set_xlabel(self.xlabel)
        ax.set_ylabel(self.ylabel)
        ax.set_title(self.title)
        ax.grid(alpha=0.3)
        ax.legend()
        fig.tight_layout()
        return fig


class PhysicsModule:
    """Subclass this to add a new kind of physics.

    1. Set `name`, `description`, `input_kind` ("video" or "audio").
    2. Write `analyze(...)` that returns a Result.
    3. Register it in modules/__init__.py.
    """
    name = ""
    description = ""
    input_kind = "video"
    # Extra options this module understands: option name -> help text
    options = {}

    def analyze(self, **kwargs) -> Result:
        raise NotImplementedError
