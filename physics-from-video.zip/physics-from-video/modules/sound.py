"""Recorded sound: pitch, note and harmonics (and string wave speed)."""
import numpy as np

from core.audio import find_spectrum_peaks, note_name, spectrum
from modules.base import PhysicsModule, Result


class Sound(PhysicsModule):
    name = "sound"
    description = "Audio (.wav) of a string, tuning fork or bottle -> frequency, note, harmonics"
    input_kind = "audio"
    options = {"string_length_m": "Vibrating string length in metres (optional, gives wave speed)"}

    def analyze(self, signal, rate, string_length_m=None, **_):
        freqs, mag = spectrum(signal, rate)
        peaks = find_spectrum_peaks(freqs, mag, min_rel_height=0.1)
        if not peaks:
            raise ValueError("No clear tone found in the recording.")

        # Fundamental = lowest strong peak (not always the loudest one)
        strongest = max(m for _, m in peaks)
        fundamental = next(f for f, m in peaks if m >= 0.25 * strongest)
        note, cents = note_name(fundamental)

        params = {"Fundamental frequency": (fundamental, "Hz")}
        notes = [f"Nearest note: {note} ({cents:+.0f} cents)"]
        harmonics = [f / fundamental for f, _ in peaks if f > 1.5 * fundamental]
        if harmonics:
            notes.append("Other peaks at x" + ", x".join(f"{h:.2f}" for h in harmonics[:6])
                         + " the fundamental.")
        if string_length_m:
            params["Wave speed on string (2 L f)"] = (2 * string_length_m * fundamental, "m/s")

        top = min(freqs[-1], max(5 * fundamental, 1000))
        return Result(module=self.name, title="Sound analysis", params=params,
                      t=freqs, observed=mag / mag.max(), xlabel="frequency (Hz)",
                      ylabel="relative strength", notes=notes,
                      markers=[f for f, _ in peaks], xlim=(0, top), line_observed=True)
