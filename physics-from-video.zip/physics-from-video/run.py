"""Command-line runner.

Examples:
    python run.py pendulum examples/pendulum.mp4 --m-per-px 0.002 --length 0.6
    python run.py projectile examples/projectile.mp4 --m-per-px 0.00667
    python run.py spring examples/spring.mp4 --m-per-px 0.002 --mass 0.5
    python run.py sound examples/string.wav --string-length 0.65
"""
import argparse
from pathlib import Path

from core.audio import load_wav
from core.calibration import meters_per_pixel
from core.pipeline import track_to_motion
from core.tracker import COLOUR_PRESETS, save_csv, track
from modules import MODULES, get_module


def build_parser():
    p = argparse.ArgumentParser(description="Discover physics from real-world video and audio.")
    p.add_argument("module", choices=list(MODULES), help="which experiment")
    p.add_argument("input", help="video (.mp4/.mov) or audio (.wav) file")

    cal = p.add_argument_group("calibration (video only): pixels -> metres")
    cal.add_argument("--m-per-px", type=float, help="metres per pixel, if you know it")
    cal.add_argument("--ref-px", type=float, help="size of a reference object in pixels")
    cal.add_argument("--ref-m", type=float, help="real size of that reference object in metres")

    trk = p.add_argument_group("tracking (video only)")
    trk.add_argument("--colour", choices=list(COLOUR_PRESETS), default="orange")
    trk.add_argument("--lower", nargs=3, type=int, metavar=("H", "S", "V"))
    trk.add_argument("--upper", nargs=3, type=int, metavar=("H", "S", "V"))
    trk.add_argument("--start", type=float, help="ignore video before this time (s)")
    trk.add_argument("--end", type=float, help="ignore video after this time (s)")
    trk.add_argument("--show", action="store_true", help="show the tracking preview window")

    ex = p.add_argument_group("extra info (optional)")
    ex.add_argument("--length", type=float, help="pendulum string length (m)")
    ex.add_argument("--mass", type=float, help="hanging mass (kg)")
    ex.add_argument("--string-length", type=float, help="vibrating string length (m)")

    p.add_argument("--out", default="results", help="folder for the plot and data")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    module = get_module(args.module)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(args.input).stem

    if module.input_kind == "audio":
        rate, signal = load_wav(args.input)
        result = module.analyze(signal=signal, rate=rate,
                                string_length_m=args.string_length)
    else:
        m_per_px = args.m_per_px
        if m_per_px is None:
            if not (args.ref_px and args.ref_m):
                raise SystemExit("Need a scale: give --m-per-px, or both --ref-px and --ref-m.")
            m_per_px = meters_per_pixel(args.ref_px, args.ref_m)
        lower, upper = COLOUR_PRESETS[args.colour]
        lower = args.lower or lower
        upper = args.upper or upper

        raw = track(args.input, lower, upper, show=args.show)
        if len(raw):
            save_csv(raw, out_dir / f"{stem}_track.csv")
        t, x, y = track_to_motion(raw, m_per_px, args.start, args.end)
        result = module.analyze(t=t, x=x, y=y, length_m=args.length, mass_kg=args.mass)

    print(result.summary())
    plot_path = out_dir / f"{stem}_{module.name}.png"
    result.plot().savefig(plot_path, dpi=130)
    print(f"\nPlot saved to {plot_path}")


if __name__ == "__main__":
    main()
