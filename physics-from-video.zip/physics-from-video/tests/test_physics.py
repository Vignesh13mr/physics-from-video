"""Tests: each module must recover physics we put in ourselves."""
import numpy as np
import pytest

from core.calibration import meters_per_pixel
from core.pipeline import video_to_motion
from core.tracker import COLOUR_PRESETS
from examples import make_demo_videos as demo
from modules import MODULES, get_module


def close(value, expected, tol):
    return abs(value - expected) <= tol * abs(expected)


def test_calibration():
    assert meters_per_pixel(500, 1.0) == pytest.approx(0.002)
    with pytest.raises(ValueError):
        meters_per_pixel(0, 1.0)


def test_pendulum_synthetic():
    L, gamma = 0.6, 0.15
    w = np.sqrt(9.81 / L - gamma ** 2)
    t = np.arange(0, 10, 1 / 30)
    x = 0.12 * np.exp(-gamma * t) * np.cos(w * t + 0.3)
    r = get_module("pendulum").analyze(t=t, x=x, y=np.zeros_like(t))
    assert close(r.params["Period"][0], 2 * np.pi / w, 0.01)
    assert close(r.params["Damping rate (gamma)"][0], gamma, 0.05)
    assert close(r.params["Effective length (if g = 9.81)"][0], L, 0.02)
    assert r.r2 > 0.999


def test_projectile_synthetic():
    t = np.arange(0, 1.0, 1 / 60)
    a = np.radians(55)
    x = 6 * np.cos(a) * t
    y = 6 * np.sin(a) * t - 0.5 * 9.81 * t ** 2
    r = get_module("projectile").analyze(t=t, x=x, y=y)
    assert close(r.params["Gravity (g)"][0], 9.81, 0.01)
    assert close(r.params["Launch speed"][0], 6.0, 0.01)
    assert close(r.params["Launch angle"][0], 55, 0.01)


def test_spring_synthetic():
    k, m, gamma = 20.0, 0.5, 0.2
    w = np.sqrt(k / m - gamma ** 2)
    t = np.arange(0, 10, 1 / 30)
    y = 0.08 * np.exp(-gamma * t) * np.cos(w * t)
    r = get_module("spring").analyze(t=t, x=np.zeros_like(t), y=y, mass_kg=m)
    assert close(r.params["Spring constant k"][0], k, 0.02)


def test_sound_synthetic():
    rate = 44100
    t = np.arange(rate) / rate
    sig = np.sin(2 * np.pi * 440 * t) + 0.4 * np.sin(2 * np.pi * 880 * t)
    r = get_module("sound").analyze(signal=sig, rate=rate, string_length_m=0.65)
    assert abs(r.params["Fundamental frequency"][0] - 440) < 1
    assert "A4" in r.notes[0]


def test_every_module_is_registered_correctly():
    for name, module in MODULES.items():
        assert module.name == name
        assert module.input_kind in ("video", "audio")


@pytest.fixture(scope="module")
def demo_dir(tmp_path_factory):
    d = tmp_path_factory.mktemp("demo")
    demo.main(d)
    return d


def test_end_to_end_pendulum_video(demo_dir):
    lo, hi = COLOUR_PRESETS["orange"]
    t, x, y = video_to_motion(demo_dir / "pendulum.mp4", 0.002, lo, hi)
    r = get_module("pendulum").analyze(t=t, x=x, y=y, length_m=0.6)
    assert close(r.params["g (from your length)"][0], 9.81, 0.03)


def test_end_to_end_projectile_video(demo_dir):
    lo, hi = COLOUR_PRESETS["orange"]
    t, x, y = video_to_motion(demo_dir / "projectile.mp4", 1 / 150, lo, hi)
    r = get_module("projectile").analyze(t=t, x=x, y=y)
    assert close(r.params["Gravity (g)"][0], 9.81, 0.05)


def test_end_to_end_spring_video(demo_dir):
    lo, hi = COLOUR_PRESETS["orange"]
    t, x, y = video_to_motion(demo_dir / "spring.mp4", 0.002, lo, hi)
    r = get_module("spring").analyze(t=t, x=x, y=y, mass_kg=0.5)
    assert close(r.params["Spring constant k"][0], 20.0, 0.05)
