"""Curve-fitting helpers shared by the physics modules."""
import numpy as np
from scipy.optimize import curve_fit


def r_squared(y, y_fit):
    """1.0 = perfect fit. Closer to 0 = poor fit."""
    ss_res = np.sum((y - y_fit) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    return float(1 - ss_res / ss_tot) if ss_tot > 0 else 0.0


def damped_cosine(t, A, gamma, omega, phi, c):
    """x(t) = A e^(-gamma t) cos(omega t + phi) + c   (a damped oscillation)."""
    return A * np.exp(-gamma * t) * np.cos(omega * t + phi) + c


def guess_frequency(t, y):
    """Rough oscillation frequency (rad/s) from the strongest FFT peak."""
    dt = float(np.median(np.diff(t)))
    yd = y - np.mean(y)
    spec = np.abs(np.fft.rfft(yd * np.hanning(len(yd)), n=8 * len(yd)))
    freqs = np.fft.rfftfreq(8 * len(yd), dt)
    spec[0] = 0
    return 2 * np.pi * freqs[np.argmax(spec)]


def fit_damped_oscillation(t, y):
    """Fit a damped cosine. Returns a dict with the parameters and the fitted curve."""
    t0 = t - t[0]
    c0 = float(np.mean(y))
    w0 = guess_frequency(t, y)
    if w0 <= 0:
        raise ValueError("No oscillation found in the data.")
    A0 = float(np.ptp(y) / 2)

    best = None
    for phi0 in (0.0, np.pi / 2, np.pi, -np.pi / 2):   # try a few starting phases
        try:
            popt, _ = curve_fit(
                damped_cosine, t0, y, p0=[A0, 0.05, w0, phi0, c0],
                bounds=([-np.inf, 0, 0.5 * w0, -2 * np.pi, -np.inf],
                        [np.inf, 20, 1.5 * w0, 2 * np.pi, np.inf]),
                maxfev=20000)
        except (RuntimeError, ValueError):
            continue
        sse = float(np.sum((y - damped_cosine(t0, *popt)) ** 2))
        if best is None or sse < best[0]:
            best = (sse, popt)
    if best is None:
        raise ValueError("Could not fit an oscillation to the data.")

    A, gamma, omega, phi, c = best[1]
    fitted = damped_cosine(t0, *best[1])
    return {"A": A, "gamma": gamma, "omega": omega, "phi": phi, "c": c,
            "fitted": fitted, "r2": r_squared(y, fitted)}
