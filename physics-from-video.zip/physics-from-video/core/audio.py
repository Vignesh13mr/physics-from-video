"""Sound analysis tools (FFT)."""
import numpy as np
from scipy.io import wavfile
from scipy.signal import find_peaks

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def load_wav(path):
    """Return (sample_rate, mono signal scaled to -1..1)."""
    rate, data = wavfile.read(path)
    data = data.astype(float)
    if data.ndim > 1:
        data = data.mean(axis=1)
    peak = np.max(np.abs(data))
    return rate, (data / peak if peak > 0 else data)


def spectrum(signal, rate):
    """Return (frequencies in Hz, magnitude) using a Hann window and zero padding."""
    n = len(signal)
    n_fft = 1 << int(np.ceil(np.log2(n * 4)))
    mag = np.abs(np.fft.rfft(signal * np.hanning(n), n=n_fft))
    freqs = np.fft.rfftfreq(n_fft, 1 / rate)
    return freqs, mag


def find_spectrum_peaks(freqs, mag, min_rel_height=0.1, min_freq=20.0):
    """Return [(frequency Hz, magnitude), ...] low to high, refined by interpolation."""
    df = freqs[1] - freqs[0]
    idx, _ = find_peaks(mag, height=min_rel_height * mag.max(),
                        distance=max(1, int(15 / df)))
    out = []
    for i in idx:
        if freqs[i] < min_freq or i == 0 or i == len(mag) - 1:
            continue
        a, b, c = mag[i - 1], mag[i], mag[i + 1]
        denom = a - 2 * b + c
        shift = 0.5 * (a - c) / denom if denom != 0 else 0.0
        out.append((freqs[i] + shift * df, mag[i]))
    return sorted(out)


def note_name(freq):
    """Nearest musical note and how many cents sharp/flat."""
    midi = int(round(69 + 12 * np.log2(freq / 440.0)))
    exact = 440.0 * 2 ** ((midi - 69) / 12)
    cents = 1200 * np.log2(freq / exact)
    return f"{NOTE_NAMES[midi % 12]}{midi // 12 - 1}", float(cents)
