"""Find a brightly coloured object in every frame of a video.

Quick check from the terminal:
    python core/tracker.py my_video.mp4
    python core/tracker.py my_video.mp4 --lower 35 100 100 --upper 85 255 255   (green)
"""
import argparse
import csv
from pathlib import Path

import cv2
import numpy as np

# HSV colour ranges (OpenCV hue runs 0-179). Tweak if your object isn't found.
COLOUR_PRESETS = {
    "orange": ((5, 150, 150), (20, 255, 255)),
    "yellow": ((20, 100, 100), (35, 255, 255)),
    "green": ((35, 80, 80), (85, 255, 255)),
    "blue": ((90, 80, 80), (130, 255, 255)),
}


def track(video_path, lower=COLOUR_PRESETS["orange"][0], upper=COLOUR_PRESETS["orange"][1],
          show=False, min_radius=5):
    """Return an array of shape (n, 3): columns are time (s), x (px), y (px).

    Frames where the object is not found are skipped.
    """
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise ValueError(f"Could not open video: {video_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    lower, upper = np.array(lower), np.array(upper)
    rows, frame_no = [], 0

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)       # 1. colour space
        mask = cv2.inRange(hsv, lower, upper)               # 2. keep matching pixels
        mask = cv2.erode(mask, None, iterations=2)          # 3. remove specks
        mask = cv2.dilate(mask, None, iterations=2)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if contours:                                        # 4. biggest blob = our object
            biggest = max(contours, key=cv2.contourArea)
            (x, y), radius = cv2.minEnclosingCircle(biggest)
            if radius > min_radius:
                rows.append((frame_no / fps, x, y))
                cv2.circle(frame, (int(x), int(y)), int(radius), (0, 255, 0), 2)

        if show:
            cv2.imshow("Tracking (press q to quit)", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
        frame_no += 1

    cap.release()
    if show:
        cv2.destroyAllWindows()
    return np.array(rows, dtype=float).reshape(-1, 3)


def first_frame(video_path):
    """Return the first frame (BGR image) of a video, or None."""
    cap = cv2.VideoCapture(str(video_path))
    ok, frame = cap.read()
    cap.release()
    return frame if ok else None


def save_csv(data, out_path):
    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["time_s", "x_px", "y_px"])
        writer.writerows(data.tolist())


def main():
    import matplotlib.pyplot as plt

    p = argparse.ArgumentParser(description="Track a coloured object in a video.")
    p.add_argument("video")
    p.add_argument("--lower", nargs=3, type=int, default=list(COLOUR_PRESETS["orange"][0]))
    p.add_argument("--upper", nargs=3, type=int, default=list(COLOUR_PRESETS["orange"][1]))
    p.add_argument("--no-show", action="store_true")
    args = p.parse_args()

    data = track(args.video, args.lower, args.upper, show=not args.no_show)
    if len(data) == 0:
        raise SystemExit("Object never found. Try other --lower / --upper values.")
    out = Path(args.video).with_suffix("").as_posix() + "_track.csv"
    save_csv(data, out)
    print(f"Tracked {len(data)} frames -> {out}")

    t, x, y = data.T
    plt.plot(x, -y)
    plt.xlabel("x (pixels)")
    plt.ylabel("height (pixels)")
    plt.title("Path of the object")
    plt.show()


if __name__ == "__main__":
    main()
