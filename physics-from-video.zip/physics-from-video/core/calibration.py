"""Turn pixels into real-world metres."""


def meters_per_pixel(ref_pixels, ref_meters):
    """Scale factor from an object of known size.

    Example: a metre stick that spans 500 pixels in the video
    -> meters_per_pixel(500, 1.0) = 0.002
    """
    if ref_pixels <= 0 or ref_meters <= 0:
        raise ValueError("Reference size must be positive (pixels and metres).")
    return ref_meters / ref_pixels


def to_meters(track, m_per_px, y_up=True):
    """Convert a (n, 3) pixel track into time, x, y in seconds / metres.

    Image y-coordinates grow downward, so by default we flip y so that
    'up' is positive, the way we draw physics graphs.
    """
    t = track[:, 0]
    x = track[:, 1] * m_per_px
    y = track[:, 2] * m_per_px
    if y_up:
        y = -y
    return t, x, y
