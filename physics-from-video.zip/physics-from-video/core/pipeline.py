"""Video -> clean motion data in metres. Used by run.py and the web app."""
from core.calibration import to_meters
from core.filtering import resample_uniform, trim
from core.tracker import track


def track_to_motion(raw, m_per_px, start=None, end=None):
    """Turn a pixel track (n, 3) into (t, x, y) in seconds and metres (y up)."""
    if len(raw) < 10:
        raise ValueError(
            f"Object found in only {len(raw)} frames. Check the colour range "
            "(--colour / --lower / --upper) and that the object stays in view.")
    t, x, y = to_meters(raw, m_per_px)
    t, (x, y) = resample_uniform(t, x, y)
    if start is not None or end is not None:
        t, (x, y) = trim(t, [x, y], start, end)
        if len(t) < 10:
            raise ValueError("Too little data left after trimming. Check --start / --end.")
    return t, x, y


def video_to_motion(video, m_per_px, lower, upper, start=None, end=None, show=False):
    """Track the object in a video and return (t, x, y) in seconds and metres."""
    return track_to_motion(track(video, lower, upper, show=show), m_per_px, start, end)
