"""Clean up tracked data."""
import numpy as np
from scipy.signal import savgol_filter


def resample_uniform(t, *signals):
    """Put the data on an evenly spaced time grid (fills any missed frames)."""
    dt = float(np.median(np.diff(t)))
    grid = np.arange(t[0], t[-1] + dt / 2, dt)
    return grid, [np.interp(grid, t, s) for s in signals]


def trim(t, signals, start=None, end=None):
    """Keep only data between start and end (seconds, measured from video start)."""
    mask = np.ones_like(t, dtype=bool)
    if start is not None:
        mask &= t >= start
    if end is not None:
        mask &= t <= end
    return t[mask], [s[mask] for s in signals]


def smooth(signal, window=9, poly=3):
    """Smooth noise with a Savitzky-Golay filter."""
    window = min(window, len(signal) - (1 - len(signal) % 2))
    if window % 2 == 0:
        window -= 1
    if window <= poly:
        return signal
    return savgol_filter(signal, window, poly)


def derivative(t, y):
    """Rate of change of y (e.g. velocity from position)."""
    return np.gradient(y, t)


def dominant_axis(x, y):
    """Pick the direction with the larger motion. Returns (signal, 'x' or 'y')."""
    return (x, "x") if np.ptp(x) >= np.ptp(y) else (y, "y")
