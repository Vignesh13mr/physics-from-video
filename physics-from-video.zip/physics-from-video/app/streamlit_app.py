"""Web app: upload a video or sound, pick the physics, see the results.

Run:  streamlit run app/streamlit_app.py
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # so `core` and `modules` import

import numpy as np
import streamlit as st

from core.audio import load_wav
from core.calibration import meters_per_pixel
from core.pipeline import track_to_motion
from core.tracker import COLOUR_PRESETS, first_frame, track
from modules import MODULES

st.set_page_config(page_title="Physics from Video", page_icon="🎯", layout="wide")
st.title("🎯 Physics from Video")
st.caption("Film or record something real. Get the physics out of it.")

name = st.sidebar.selectbox("Experiment", list(MODULES), format_func=lambda n: f"{n} – {MODULES[n].description}")
module = MODULES[name]
is_video = module.input_kind == "video"

upload_types = ["mp4", "mov", "avi", "m4v"] if is_video else ["wav"]
upload = st.file_uploader(f"Upload a {'video' if is_video else '.wav recording'}", type=upload_types)

# --- extra, module-specific inputs -------------------------------------------------
extra = {}
if name == "pendulum":
    use = st.sidebar.checkbox("I know the string length")
    if use:
        extra["length_m"] = st.sidebar.number_input("String length (m)", 0.05, 10.0, 0.6, 0.01)
elif name == "spring":
    use = st.sidebar.checkbox("I know the mass")
    if use:
        extra["mass_kg"] = st.sidebar.number_input("Mass (kg)", 0.001, 50.0, 0.5, 0.01)
elif name == "sound":
    use = st.sidebar.checkbox("I know the string length")
    if use:
        extra["string_length_m"] = st.sidebar.number_input("String length (m)", 0.01, 5.0, 0.65, 0.01)

if is_video:
    st.sidebar.subheader("Object colour")
    preset = st.sidebar.selectbox("Colour of the tracked object", list(COLOUR_PRESETS))
    lower, upper = COLOUR_PRESETS[preset]
    if st.sidebar.checkbox("Custom HSV range"):
        lower = tuple(st.sidebar.slider(f"Lower {c}", 0, 255, v) for c, v in zip("HSV", lower))
        upper = tuple(st.sidebar.slider(f"Upper {c}", 0, 255, v) for c, v in zip("HSV", upper))

    st.sidebar.subheader("Scale (pixels → metres)")
    ref_px = st.sidebar.number_input("Reference length in pixels", 1.0, 5000.0, 500.0, 1.0)
    ref_m = st.sidebar.number_input("Same length in metres", 0.001, 100.0, 1.0, 0.01)

    st.sidebar.subheader("Time window (optional)")
    start = st.sidebar.number_input("Start (s)", 0.0, 600.0, 0.0, 0.1)
    end = st.sidebar.number_input("End (s, 0 = until the end)", 0.0, 600.0, 0.0, 0.1)

if upload is None:
    st.info("Upload a file to begin. No file yet? Run `python examples/make_demo_videos.py` "
            "to create demo files with known physics.")
    st.stop()

# --- run -------------------------------------------------------------------------
suffix = Path(upload.name).suffix
with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
    tmp.write(upload.getbuffer())
    path = tmp.name

try:
    if is_video:
        frame = first_frame(path)
        if frame is not None:
            h, w = frame.shape[:2]
            st.image(frame[:, :, ::-1], caption=f"First frame ({w}×{h} px). Measure a known "
                     "length here to set the scale.", width=480)
        if st.button("Analyze", type="primary"):
            with st.spinner("Tracking the object…"):
                raw = track(path, lower, upper)
                t, x, y = track_to_motion(raw, meters_per_pixel(ref_px, ref_m),
                                          start or None, end or None)
                result = module.analyze(t=t, x=x, y=y, **extra)
            st.session_state["result"] = (result, np.column_stack([t, x, y]))
    else:
        if st.button("Analyze", type="primary"):
            rate, signal = load_wav(path)
            st.session_state["result"] = (module.analyze(signal=signal, rate=rate, **extra), None)
except Exception as err:  # show friendly messages instead of a stack trace
    st.error(str(err))
    st.stop()

if "result" in st.session_state:
    result, motion = st.session_state["result"]
    left, right = st.columns([3, 2])
    left.pyplot(result.plot())
    right.subheader("Results")
    right.table({"Quantity": list(result.params),
                 "Value": [f"{v:.4g} {u}".strip() for v, u in result.params.values()]})
    if result.r2 is not None:
        right.metric("Fit quality (R²)", f"{result.r2:.4f}")
    for n in result.notes:
        right.caption(n)
    if motion is not None:
        csv = "time_s,x_m,y_m\n" + "\n".join(",".join(f"{v:.6g}" for v in row) for row in motion)
        right.download_button("Download motion data (CSV)", csv, "motion.csv", "text/csv")
